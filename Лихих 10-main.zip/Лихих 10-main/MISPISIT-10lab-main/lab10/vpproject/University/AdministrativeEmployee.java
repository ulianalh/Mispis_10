package University;

public class AdministrativeEmployee extends Employee {
    public AdministrativeEmployee(int ssn, String name, String email) {
        super(ssn, name, email);
    }
}